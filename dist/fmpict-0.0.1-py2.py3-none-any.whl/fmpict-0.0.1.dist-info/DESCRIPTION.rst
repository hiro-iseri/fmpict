Combinatorial testing tool using FreeMind and PICT


